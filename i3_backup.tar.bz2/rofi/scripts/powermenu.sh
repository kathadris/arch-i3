#!/usr/bin/env bash

theme="$HOME/.config/rofi/themes/midnight-power.rasi"

options=" Lock\n Logout\n Suspend\n Reboot\n Shutdown\n Hibernate"

chosen="$(printf "$options" | rofi -dmenu -i -p "" -theme "$theme")"

case "$chosen" in
    " Lock")
        # Change this to your lock command
        i3lock
        ;;
    " Logout")
        # Change depending on your WM/DE
        pkill -KILL -u "$USER"
        ;;
    " Suspend")
        systemctl suspend
        ;;
    " Reboot")
        systemctl reboot
        ;;
    " Shutdown")
        systemctl poweroff
        ;;
    " Hibernate")
        systemctl hibernate
        ;;
esac
